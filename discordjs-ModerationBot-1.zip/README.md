# discord.js-ModerationBot
ModerationBot V1 is a simple moderation bot with all basics commands that a bot needs!! This is the First version of this bot and the bot gets updated with new version every month!

**Thanks for Choosing MODERATION.V1**
