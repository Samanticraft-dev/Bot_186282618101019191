exports.Prefix = `!`;
exports.Token = `OTA1NDM0MDgyOTU4Mjc4NzE3.YYKBMw.CTNCDrl1KmmqCfgOOx4UI4jFA5c`;
exports.Color = `RANDOM`;
